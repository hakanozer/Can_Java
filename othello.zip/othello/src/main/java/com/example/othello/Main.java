package com.example.othello;

public class Main {
    public static void main(String[] args) {
    }
}
