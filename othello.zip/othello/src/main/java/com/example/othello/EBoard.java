package com.example.othello;

public enum EBoard {

    empty, suggestion, black, white;
}
